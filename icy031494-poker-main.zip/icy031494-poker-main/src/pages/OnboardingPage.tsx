import { useState, type FormEvent } from 'react';
import { Spade } from 'lucide-react';
import { createPlayer } from '@/lib/api';
import { errorMessage } from '@/lib/format';
import { writeStoredPlayer, type StoredPlayer } from '@/lib/identity';

interface OnboardingPageProps {
  onJoined: (player: StoredPlayer) => void;
}

const NAME_MIN = 2;
const NAME_MAX = 24;

export function OnboardingPage({ onJoined }: OnboardingPageProps) {
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const trimmed = name.trim();
  const valid = trimmed.length >= NAME_MIN && trimmed.length <= NAME_MAX;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!valid || busy) return;
    setBusy(true);
    setError(null);
    try {
      const row = await createPlayer(trimmed);
      const player = { id: row.id, name: row.display_name };
      writeStoredPlayer(player);
      onJoined(player);
    } catch (err) {
      setError(errorMessage(err));
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center">
      <div className="rounded-3xl border border-white/10 bg-slate-900/80 p-8 shadow-2xl">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gold-400/15 text-gold-300">
          <Spade className="h-6 w-6" />
        </span>
        <h1 className="mt-5 text-2xl font-semibold text-white">Welcome to the table</h1>
        <p className="mt-2 text-sm text-slate-400">Pick a display name. Other players at the table will see it.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <label className="block">
            <span className="text-xs font-medium text-slate-400">Display name</span>
            <input
              type="text"
              autoFocus
              maxLength={NAME_MAX}
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder="e.g. Juan D."
              className="mt-1 w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-white outline-none placeholder:text-slate-600 focus:border-gold-400/60"
            />
            <span className="mt-1 block text-xs text-slate-500">
              {NAME_MIN} to {NAME_MAX} characters
            </span>
          </label>

          {error && (
            <p role="alert" className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={!valid || busy}
            className="w-full rounded-xl bg-gradient-to-b from-gold-300 to-gold-500 py-3 text-sm font-bold text-slate-900 transition hover:brightness-105 disabled:opacity-40"
          >
            {busy ? 'Joining...' : 'Enter the room'}
          </button>
        </form>
      </div>
    </div>
  );
}
