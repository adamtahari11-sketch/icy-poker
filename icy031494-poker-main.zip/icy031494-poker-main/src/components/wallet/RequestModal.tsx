import { useState, type FormEvent } from 'react';
import { Modal } from '@/components/common/Modal';
import { submitTransactionRequest } from '@/lib/api';
import { errorMessage, formatPeso } from '@/lib/format';
import type { PaymentMethod, TransactionType } from '@/lib/models';

const METHODS: { value: PaymentMethod; label: string }[] = [
  { value: 'gcash', label: 'GCash' },
  { value: 'maya', label: 'Maya' },
  { value: 'bank', label: 'Bank transfer' },
];

interface RequestModalProps {
  mode: TransactionType;
  playerId: string;
  balance: number;
  onClose: () => void;
}

export function RequestModal({ mode, playerId, balance, onClose }: RequestModalProps) {
  const [method, setMethod] = useState<PaymentMethod>('gcash');
  const [amount, setAmount] = useState('');
  const [details, setDetails] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const isCashIn = mode === 'cash_in';
  const amountValue = Number(amount);
  const amountError =
    amount === ''
      ? null
      : !(amountValue > 0)
        ? 'Enter an amount greater than zero.'
        : !isCashIn && amountValue > balance
          ? `You can withdraw up to ${formatPeso(balance)}.`
          : null;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (amountError || !(amountValue > 0)) {
      setError(amountError ?? 'Enter an amount greater than zero.');
      return;
    }
    if (details.trim().length < 4) {
      setError(isCashIn ? 'Enter the reference number of your payment.' : 'Enter your account number or name.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await submitTransactionRequest({
        playerId,
        type: mode,
        amount: amountValue,
        method,
        accountDetails: details.trim(),
      });
      setDone(true);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal title={isCashIn ? 'Cash in to your wallet' : 'Withdraw from your wallet'} onClose={onClose}>
      {done ? (
        <div className="space-y-4 text-center">
          <p className="text-base font-semibold text-emerald-300">Request sent</p>
          <p className="text-sm text-slate-300">
            The admin will review it shortly. Your balance updates automatically once it is approved.
          </p>
          <button type="button" onClick={onClose} className="w-full rounded-xl bg-white/10 py-2.5 text-sm font-semibold text-white hover:bg-white/15">
            Done
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          <p className="text-sm text-slate-400">
            {isCashIn
              ? 'Send your payment using the details the admin gives you, then enter the reference number below.'
              : 'Enter where you want to receive your money. The admin deducts your balance once the withdrawal is approved.'}
          </p>

          <fieldset className="space-y-2">
            <legend className="mb-2 text-xs font-medium uppercase tracking-wider text-slate-400">Method</legend>
            <div className="grid grid-cols-3 gap-2">
              {METHODS.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setMethod(option.value)}
                  aria-pressed={method === option.value}
                  className={`rounded-lg border py-2 text-sm font-medium transition ${
                    method === option.value
                      ? 'border-gold-400 bg-gold-400/10 text-gold-300'
                      : 'border-white/10 text-slate-300 hover:border-white/30'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </fieldset>

          <div className="space-y-2">
            <label htmlFor="request-amount" className="text-xs font-medium uppercase tracking-wider text-slate-400">
              Amount (PHP)
            </label>
            <input
              id="request-amount"
              type="number"
              min="1"
              step="0.01"
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
              className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-lg font-semibold tabular-nums text-white outline-none focus:border-gold-400/60"
            />
            {amountError && <p className="text-xs text-amber-300">{amountError}</p>}
          </div>

          <div className="space-y-2">
            <label htmlFor="request-details" className="text-xs font-medium uppercase tracking-wider text-slate-400">
              {isCashIn ? 'Reference number' : 'Account number or name'}
            </label>
            <input
              id="request-details"
              type="text"
              maxLength={60}
              value={details}
              onChange={(event) => setDetails(event.target.value)}
              placeholder={isCashIn ? 'e.g. 1234567890' : 'e.g. 09XX XXX XXXX - Juan D.'}
              className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-sm text-white outline-none placeholder:text-slate-600 focus:border-gold-400/60"
            />
          </div>

          {error && (
            <p role="alert" className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting || !!amountError}
            className="w-full rounded-xl bg-gradient-to-b from-gold-300 to-gold-500 py-3 text-sm font-bold text-slate-900 shadow-lg transition hover:brightness-110 disabled:opacity-40"
          >
            {submitting ? 'Sending request...' : isCashIn ? 'Submit cash-in request' : 'Submit withdrawal request'}
          </button>
        </form>
      )}
    </Modal>
  );
}
