import { BIG_BLIND, SEAT_COUNT } from '@/poker/engine';
import type { Seat, TableState } from '@/poker/types';

export interface RemotePlayer {
  id: string;
  name: string;
}

export const BOT_ROSTER = [
  { name: 'Ariana', tone: 0 },
  { name: 'Mateo', tone: 1 },
  { name: 'Kenji', tone: 2 },
  { name: 'Sofia', tone: 3 },
  { name: 'Dante', tone: 4 },
  { name: 'Yuna', tone: 5 },
  { name: 'Leo', tone: 6 },
  { name: 'Priya', tone: 7 },
];

const BOT_STACK_MIN = 1000;
const BOT_STACK_MAX = 2500;

function randomBotStack(): number {
  const span = (BOT_STACK_MAX - BOT_STACK_MIN) / 10;
  return BOT_STACK_MIN + Math.floor(Math.random() * span) * 10;
}

export function createHumanSeat(id: string, name: string, stack: number, tone: number): Seat {
  return {
    id,
    name,
    isBot: false,
    isMe: true,
    tone,
    stack,
    bet: 0,
    invested: 0,
    hole: [],
    folded: false,
    allIn: false,
    acted: false,
    sittingOut: false,
  };
}

function createBotSeat(name: string, tone: number): Seat {
  return {
    id: `bot-${name.toLowerCase()}-${Math.random().toString(36).slice(2, 7)}`,
    name,
    isBot: true,
    isMe: false,
    tone,
    stack: randomBotStack(),
    bet: 0,
    invested: 0,
    hole: [],
    folded: false,
    allIn: false,
    acted: false,
    sittingOut: false,
  };
}

function createRemoteSeat(player: RemotePlayer, tone: number): Seat {
  return {
    id: player.id,
    name: player.name,
    isBot: false,
    isMe: false,
    tone,
    stack: 0,
    bet: 0,
    invested: 0,
    hole: [],
    folded: true,
    allIn: false,
    acted: false,
    sittingOut: true,
  };
}

function firstEmptySeat(seats: (Seat | null)[]): number {
  return seats.findIndex((seat) => seat === null);
}

function lastBotSeat(seats: (Seat | null)[]): number {
  for (let index = seats.length - 1; index >= 0; index--) {
    if (seats[index]?.isBot) return index;
  }
  return -1;
}

function pickBotName(seats: (Seat | null)[]): { name: string; tone: number } {
  const used = new Set(seats.map((seat) => seat?.name));
  const available = BOT_ROSTER.filter((bot) => !used.has(bot.name));
  const pool = available.length > 0 ? available : BOT_ROSTER;
  return pool[Math.floor(Math.random() * pool.length)];
}

// Real players take priority over bots: a bot gives up its seat when a real player sits down.
// Bots only ever occupy seats between hands, so no hand is disturbed by a swap.
export function reconcileSeats(table: TableState, remotes: RemotePlayer[]): TableState {
  const seats: (Seat | null)[] = table.seats.map((seat) => (seat ? { ...seat, hole: [] } : null));
  const remoteIds = new Set(remotes.map((player) => player.id));

  seats.forEach((seat, index) => {
    if (seat && !seat.isBot && !seat.isMe && !remoteIds.has(seat.id)) seats[index] = null;
  });

  const seatedRemoteIds = new Set(
    seats.flatMap((seat) => (seat && !seat.isBot && !seat.isMe ? [seat.id] : []))
  );

  for (const player of remotes) {
    if (seatedRemoteIds.has(player.id)) continue;
    let slot = firstEmptySeat(seats);
    if (slot === -1) {
      const bot = lastBotSeat(seats);
      if (bot === -1) break;
      seats[bot] = null;
      slot = bot;
    }
    seats[slot] = createRemoteSeat(player, slot);
  }

  const humanCount = seats.filter((seat) => seat && !seat.isBot).length;
  const targetBots = Math.max(0, SEAT_COUNT - humanCount);

  let botCount = seats.filter((seat) => seat?.isBot).length;
  while (botCount > targetBots) {
    const bot = lastBotSeat(seats);
    if (bot === -1) break;
    seats[bot] = null;
    botCount--;
  }
  while (botCount < targetBots) {
    const slot = firstEmptySeat(seats);
    if (slot === -1) break;
    const { name, tone } = pickBotName(seats);
    seats[slot] = createBotSeat(name, tone);
    botCount++;
  }

  for (const seat of seats) {
    if (seat?.isBot && seat.stack < BIG_BLIND * 5) seat.stack = randomBotStack();
  }

  return { ...table, seats };
}
