import { useState } from 'react';
import { LogOut, ShieldCheck, Spade } from 'lucide-react';
import { useHashPath } from '@/hooks/useHashPath';
import { AdminPage } from '@/pages/AdminPage';
import { OnboardingPage } from '@/pages/OnboardingPage';
import { TablePage } from '@/pages/TablePage';
import { clearStoredPlayer, readStoredPlayer, type StoredPlayer } from '@/lib/identity';

function App() {
  const path = useHashPath();
  const [player, setPlayer] = useState<StoredPlayer | null>(readStoredPlayer);
  const isAdmin = path.startsWith('/admin');

  function signOut() {
    clearStoredPlayer();
    setPlayer(null);
    window.location.hash = '#/';
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="sticky top-0 z-20 border-b border-white/5 bg-slate-950/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <a href="#/" className="flex items-center gap-2 font-semibold text-white">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gold-400/15 text-gold-300">
              <Spade className="h-4 w-4" />
            </span>
            Poker Room
          </a>
          <nav className="flex items-center gap-2 text-sm">
            <a
              href="#/"
              className={`rounded-lg px-3 py-1.5 transition ${!isAdmin ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Table
            </a>
            <a
              href="#/admin"
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 transition ${isAdmin ? 'bg-white/10 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              <ShieldCheck className="h-4 w-4" /> Admin
            </a>
            {player && !isAdmin && (
              <button
                type="button"
                onClick={signOut}
                className="ml-2 hidden items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 text-slate-300 transition hover:border-white/25 hover:text-white sm:inline-flex"
              >
                <LogOut className="h-4 w-4" /> {player.name}
              </button>
            )}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {isAdmin ? <AdminPage /> : player ? <TablePage player={player} /> : <OnboardingPage onJoined={setPlayer} />}
      </main>
    </div>
  );
}

export default App;
