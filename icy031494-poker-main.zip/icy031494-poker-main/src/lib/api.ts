import { supabase } from '@/lib/supabase';
import {
  DEFAULT_TABLE_SETTINGS,
  type AccountStatus,
  type GameLogRow,
  type PaymentMethod,
  type PlayerRow,
  type TableSettings,
  type TransactionRow,
  type TransactionType,
} from '@/lib/models';

function must<T>(result: { data: T; error: { message: string } | null }): T {
  if (result.error) throw new Error(result.error.message);
  return result.data;
}

export async function createPlayer(displayName: string): Promise<PlayerRow> {
  const row = must(
    await supabase.from('players').insert({ display_name: displayName }).select('*').single()
  );
  return row as PlayerRow;
}

export async function fetchPlayer(playerId: string): Promise<PlayerRow | null> {
  return must(await supabase.from('players').select('*').eq('id', playerId).maybeSingle()) as PlayerRow | null;
}

export async function fetchAllPlayers(): Promise<PlayerRow[]> {
  return must(
    await supabase.from('players').select('*').order('created_at', { ascending: false }).limit(500)
  ) as PlayerRow[];
}

export async function fetchPlayerTransactions(playerId: string): Promise<TransactionRow[]> {
  return must(
    await supabase
      .from('transactions')
      .select('*')
      .eq('player_id', playerId)
      .order('created_at', { ascending: false })
      .limit(20)
  ) as TransactionRow[];
}

export async function fetchAllTransactions(): Promise<TransactionRow[]> {
  return must(
    await supabase
      .from('transactions')
      .select('*, players(display_name, balance)')
      .order('created_at', { ascending: false })
      .limit(200)
  ) as TransactionRow[];
}

export async function submitTransactionRequest(input: {
  playerId: string;
  type: TransactionType;
  amount: number;
  method: PaymentMethod;
  accountDetails: string;
}): Promise<void> {
  must(
    await supabase.from('transactions').insert({
      player_id: input.playerId,
      type: input.type,
      amount: input.amount,
      method: input.method,
      account_details: input.accountDetails,
    })
  );
}

export async function fetchGameLogs(): Promise<GameLogRow[]> {
  return must(
    await supabase.from('game_logs').select('*').order('id', { ascending: false }).limit(200)
  ) as GameLogRow[];
}

export async function fetchTableSettings(): Promise<TableSettings> {
  const rows = must(await supabase.from('settings').select('key, value')) as {
    key: string;
    value: unknown;
  }[];
  const map = new Map(rows.map((row) => [row.key, row.value]));
  const aggression = map.get('bot_aggression');
  return {
    rakePercent: Number(map.get('rake_percent') ?? DEFAULT_TABLE_SETTINGS.rakePercent),
    botAggression:
      aggression === 'passive' || aggression === 'aggressive' || aggression === 'balanced'
        ? aggression
        : DEFAULT_TABLE_SETTINGS.botAggression,
    minBuyIn: Number(map.get('min_buy_in') ?? DEFAULT_TABLE_SETTINGS.minBuyIn),
    maxBuyIn: Number(map.get('max_buy_in') ?? DEFAULT_TABLE_SETTINGS.maxBuyIn),
  };
}

export async function verifyAdminKey(adminKey: string): Promise<boolean> {
  return must(await supabase.rpc('admin_verify', { p_admin_key: adminKey })) as boolean;
}

export async function resolveTransaction(
  adminKey: string,
  transactionId: string,
  decision: 'approve' | 'reject',
  note: string | null
): Promise<void> {
  must(
    await supabase.rpc('resolve_transaction', {
      p_admin_key: adminKey,
      p_id: transactionId,
      p_decision: decision,
      p_note: note,
    })
  );
}

export async function adminSetBalance(adminKey: string, playerId: string, balance: number): Promise<void> {
  must(
    await supabase.rpc('admin_set_balance', {
      p_admin_key: adminKey,
      p_player: playerId,
      p_balance: balance,
    })
  );
}

export async function adminSetPlayerStatus(
  adminKey: string,
  playerId: string,
  status: AccountStatus
): Promise<void> {
  must(
    await supabase.rpc('admin_set_player_status', {
      p_admin_key: adminKey,
      p_player: playerId,
      p_status: status,
    })
  );
}

export async function adminSetSetting(adminKey: string, key: string, value: string | number): Promise<void> {
  must(await supabase.rpc('admin_set_setting', { p_admin_key: adminKey, p_key: key, p_value: value }));
}

export async function pokerBuyIn(playerId: string, amount: number): Promise<string> {
  return must(await supabase.rpc('poker_buy_in', { p_player: playerId, p_amount: amount })) as string;
}

export async function pokerCashOut(sessionId: string, amount: number): Promise<number> {
  return must(
    await supabase.rpc('poker_cash_out', { p_session: sessionId, p_amount: amount })
  ) as number;
}
