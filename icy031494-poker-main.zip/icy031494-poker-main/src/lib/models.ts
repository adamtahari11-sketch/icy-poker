import type { Aggression } from '@/poker/types';

export type TransactionType = 'cash_in' | 'cash_out';
export type TransactionStatus = 'pending' | 'approved' | 'rejected';
export type PaymentMethod = 'gcash' | 'maya' | 'bank';
export type AccountStatus = 'active' | 'frozen';
export type LogLevel = 'info' | 'warn' | 'error' | 'admin';

export interface PlayerRow {
  id: string;
  display_name: string;
  balance: number;
  status: AccountStatus;
  created_at: string;
}

export interface TransactionRow {
  id: string;
  player_id: string;
  type: TransactionType;
  amount: number;
  method: PaymentMethod;
  account_details: string;
  status: TransactionStatus;
  admin_note: string | null;
  created_at: string;
  resolved_at: string | null;
  players?: { display_name: string; balance: number } | null;
}

export interface GameLogRow {
  id: number;
  level: LogLevel;
  message: string;
  player_id: string | null;
  created_at: string;
}

export interface TableSettings {
  rakePercent: number;
  botAggression: Aggression;
  minBuyIn: number;
  maxBuyIn: number;
}

export const DEFAULT_TABLE_SETTINGS: TableSettings = {
  rakePercent: 5,
  botAggression: 'balanced',
  minBuyIn: 500,
  maxBuyIn: 20000,
};
